import Button from "@/components/common/Button/Button";
import Badge from "@/components/common/Badge/Badge";

export default function StyleGuide() {
  return (
    <div className="container styleguide">
      <div className="crumb">🎨 System</div>
      <h1 className="page-title">Style Guide</h1>
      <p className="styleguide__desc">
        Tokens 기반으로 구성된 컴포넌트/테마 시스템 미리보기 화면입니다.
      </p>

      {/* Foundations */}
      <section className="styleguide__section">
        <h2 className="styleguide__title">Foundations</h2>

        <div className="grid-2">
          <div className="panel panel--glass">
            <div className="panel__inner">
              <h3 className="styleguide__subtitle">Colors</h3>

              <div className="styleguide__swatches">
                <div className="swatch swatch--bg">bg</div>
                <div className="swatch swatch--surface">surface</div>
                <div className="swatch swatch--primary">primary</div>
                <div className="swatch swatch--accent">accent</div>
                <div className="swatch swatch--pink">pink</div>
              </div>
            </div>
          </div>

          <div className="panel panel--glass">
            <div className="panel__inner">
              <h3 className="styleguide__subtitle">Typography</h3>

              <div className="styleguide__typo">
                <p className="t-xl">Heading XL</p>
                <p className="t-lg">Heading LG</p>
                <p className="t-md">Body MD</p>
                <p className="t-sm">Body SM</p>
                <p className="t-xs">Caption XS</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Components */}
      <section className="styleguide__section">
        <h2 className="styleguide__title">Components</h2>

        <div className="grid-2">
          <div className="card">
            <h3 className="styleguide__subtitle">Buttons</h3>

            <div className="styleguide__row">
              <Button size="xs" variant="primary">XS</Button>
              <Button size="sm" variant="primary">SM</Button>
              <Button size="md" variant="primary">MD</Button>
              <Button size="lg" variant="primary">LG</Button>
              <Button size="xl" variant="primary">XL</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" variant="outline">Outline</Button>
              <Button size="md" variant="ghost">Ghost</Button>
              <Button size="md" variant="danger">Danger</Button>
              <Button size="md" variant="primary" disabled>Disabled</Button>
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Inputs</h3>

            <div className="styleguide__form">
              <label className="field">
                <span className="field__label">프로젝트명</span>
                <input className="input" placeholder="AAA" />
              </label>

              <label className="field">
                <span className="field__label">비고</span>
                <textarea className="textarea" placeholder="간단 설명..." rows={4} />
              </label>
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Badges</h3>
            <div className="styleguide__row">
              <Badge label="React" />
              <Badge label="TypeScript" />
              <Badge label="SCSS" />
              <Badge label="Vite" />
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Cards</h3>
            <div className="card" style={{ marginTop: 12 }}>
              <h4 className="card__title">Project Card</h4>
              <p className="card__meta">Client · Role</p>
              <p className="card__period">2025-01-01 ~ 2025-12-31</p>
              <div className="btn-group" style={{ marginTop: 12 }}>
                <Badge label="React" />
                <Badge label="TypeScript" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
