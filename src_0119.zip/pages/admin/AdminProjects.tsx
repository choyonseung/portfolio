import { useEffect, useState } from "react";
import type { Project } from "@/types/project";
import { projectStorage } from "@/services/storage/projectStorage";

function createProject(): Project {
  return {
    id: crypto.randomUUID(),
    name: "",
    client: "",
    role: "",
    startDate: "",
    endDate: "",
    skillsText: "",
    skills: [],
    note: "",
  };
}

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    setProjects(projectStorage.get());
  }, []);

  const onAdd = () => setProjects((prev) => [createProject(), ...prev]);

  const onRemove = (id: string) =>
    setProjects((prev) => prev.filter((p) => p.id !== id));

  const update = (id: string, patch: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...patch } : p))
    );
  };

  const onSave = () => {
    const normalized = projects.map((p) => ({
      ...p,
      skills: p.skillsText
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
    }));

    setProjects(normalized);
    projectStorage.set(normalized);
    alert("저장 완료!");
  };


  return (
    <div style={{ maxWidth: 1000, margin: "0 auto" }}>
      <h1>프로젝트 이력 입력</h1>

      <div style={{ display: "flex", gap: 12, marginTop: 16 }}>
        <button onClick={onAdd}>+ 프로젝트 추가</button>
        <button onClick={onSave}>저장</button>
        <button
          onClick={() => {
            projectStorage.clear();
            alert("저장값 삭제 완료");
          }}
        >
          저장값 삭제
        </button>
      </div>

      <div style={{ marginTop: 20, display: "grid", gap: 14 }}>
        {projects.map((p, idx) => (
          <div
            key={p.id}
            style={{
              border: "1px solid #ddd",
              borderRadius: 14,
              padding: 16,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <b>#{idx + 1}</b>
              <button onClick={() => onRemove(p.id)}>삭제</button>
            </div>

            <div style={{ marginTop: 12 }}>
              <label>프로젝트명</label>
              <input
                value={p.name}
                onChange={(e) => update(p.id, { name: e.target.value })}
                style={{ display: "block", width: "100%", marginTop: 6 }}
              />
            </div>

            <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
              <div style={{ flex: 1 }}>
                <label>발주처</label>
                <input
                  value={p.client}
                  onChange={(e) => update(p.id, { client: e.target.value })}
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>

              <div style={{ flex: 1 }}>
                <label>담당역할</label>
                <input
                  value={p.role}
                  onChange={(e) => update(p.id, { role: e.target.value })}
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>
            </div>

            <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
              <div style={{ flex: 1 }}>
                <label>시작일</label>
                <input
                  type="date"
                  value={p.startDate}
                  onChange={(e) => update(p.id, { startDate: e.target.value })}
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>
              <div style={{ flex: 1 }}>
                <label>종료일</label>
                <input
                  type="date"
                  value={p.endDate}
                  onChange={(e) => update(p.id, { endDate: e.target.value })}
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>
            </div>

            <div style={{ marginTop: 12 }}>
              <label>사용스킬 (쉼표로 구분)</label>
              <input
                value={p.skillsText}
                onChange={(e) => update(p.id, { skillsText: e.target.value })}
                placeholder="React, TypeScript, SCSS..."
                style={{ display: "block", width: "100%", marginTop: 6 }}
              />
            </div>

            <div style={{ marginTop: 12 }}>
              <label>비고</label>
              <textarea
                value={p.note || ""}
                onChange={(e) => update(p.id, { note: e.target.value })}
                rows={3}
                style={{ display: "block", width: "100%", marginTop: 6 }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}