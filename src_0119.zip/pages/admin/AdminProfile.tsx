import { useEffect, useMemo, useState } from "react";
import type { Career, Profile } from "@/types/profile";
import { profileStorage } from "@/services/storage/profileStorage";
import { calcTotalCareer } from "@/utils/calcCareer";

function createCareer(): Career {
  return {
    id: crypto.randomUUID(),
    companyName: "",
    startDate: "",
    endDate: "",
    isCurrent: false,
  };
}

export default function AdminProfile() {
  const [profile, setProfile] = useState<Profile>({
    name: "",
    location: "",
    careers: [createCareer()],
  });

  // 기존 저장값 불러오기
  useEffect(() => {
    const saved = profileStorage.get();
    if (saved) setProfile(saved);
  }, []);

  const total = useMemo(
    () => calcTotalCareer(profile.careers),
    [profile.careers]
  );

  const onSave = () => {
    profileStorage.set(profile);
    alert("저장 완료!");
  };

  const onAddCareer = () => {
    setProfile((prev) => ({
      ...prev,
      careers: [...prev.careers, createCareer()],
    }));
  };

  const onRemoveCareer = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      careers: prev.careers.filter((c) => c.id !== id),
    }));
  };

  const updateCareer = (id: string, patch: Partial<Career>) => {
    setProfile((prev) => ({
      ...prev,
      careers: prev.careers.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  };

  return (
    <div style={{ maxWidth: 900, margin: "0 auto" }}>
      <h1>개인정보 입력</h1>

      <div style={{ marginTop: 20 }}>
        <label>이름</label>
        <input
          value={profile.name}
          onChange={(e) => setProfile({ ...profile, name: e.target.value })}
          style={{ display: "block", width: "100%", marginTop: 6 }}
        />
      </div>

      <div style={{ marginTop: 16 }}>
        <label>거주지(활동지)</label>
        <input
          value={profile.location}
          onChange={(e) => setProfile({ ...profile, location: e.target.value })}
          style={{ display: "block", width: "100%", marginTop: 6 }}
        />
      </div>

      <div style={{ marginTop: 30 }}>
        <h2>회사 이력</h2>

        <p>
          총 경력: <b>{total.years}년 {total.months}개월</b>
        </p>

        {profile.careers.map((c, idx) => (
          <div
            key={c.id}
            style={{
              padding: 16,
              border: "1px solid #ddd",
              borderRadius: 12,
              marginTop: 12,
            }}
          >
            <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
              <b>#{idx + 1}</b>
              <button onClick={() => onRemoveCareer(c.id)}>삭제</button>
            </div>

            <div style={{ marginTop: 10 }}>
              <label>회사명</label>
              <input
                value={c.companyName}
                onChange={(e) =>
                  updateCareer(c.id, { companyName: e.target.value })
                }
                style={{ display: "block", width: "100%", marginTop: 6 }}
              />
            </div>

            <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
              <div style={{ flex: 1 }}>
                <label>시작일</label>
                <input
                  type="date"
                  value={c.startDate}
                  onChange={(e) =>
                    updateCareer(c.id, { startDate: e.target.value })
                  }
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>

              <div style={{ flex: 1 }}>
                <label>종료일</label>
                <input
                  type="date"
                  value={c.endDate || ""}
                  disabled={c.isCurrent}
                  onChange={(e) =>
                    updateCareer(c.id, { endDate: e.target.value })
                  }
                  style={{ display: "block", width: "100%", marginTop: 6 }}
                />
              </div>
            </div>

            <div style={{ marginTop: 10 }}>
              <label>
                <input
                  type="checkbox"
                  checked={c.isCurrent}
                  onChange={(e) =>
                    updateCareer(c.id, {
                      isCurrent: e.target.checked,
                      endDate: e.target.checked ? "" : c.endDate,
                    })
                  }
                />
                재직중
              </label>
            </div>
          </div>
        ))}

        <button onClick={onAddCareer} style={{ marginTop: 16 }}>
          + 회사 추가
        </button>
      </div>

      <div style={{ marginTop: 30, display: "flex", gap: 12 }}>
        <button onClick={onSave}>저장</button>
        <button
          onClick={() => {
            profileStorage.clear();
            alert("저장값 삭제 완료");
          }}
        >
          저장값 삭제
        </button>
      </div>
    </div>
  );
}