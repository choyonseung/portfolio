import { Link } from "react-router-dom";
import { profileStorage } from "@/services/storage/profileStorage";
import { projectStorage } from "@/services/storage/projectStorage";
import { downloadJson, readJsonFile } from "@/utils/jsonFile";
import type { Profile } from "@/types/profile";
import type { Project } from "@/types/project";

type BackupData = {
  profile: Profile | null;
  projects: Project[];
  exportedAt: string;
};

export default function AdminHome() {
  const onExport = () => {
    const backup: BackupData = {
      profile: profileStorage.get(),
      projects: projectStorage.get(),
      exportedAt: new Date().toISOString(),
    };

    downloadJson("portfolio-backup.json", backup);
  };

  const onImport = async (file: File | null) => {
    if (!file) return;

    try {
      const backup = await readJsonFile<BackupData>(file);
      if (backup.profile) profileStorage.set(backup.profile);
      projectStorage.set(backup.projects ?? []);
      alert("복구 완료! Home에서 확인해봐 😎");
    } catch {
      alert("JSON 파일 형식이 이상해! (복구 실패)");
    }
  };

  return (
    <div className="container admin">
      <div className="page">
        <div className="page__crumb">🏠 Home / Admin</div>
        <h1 className="page__title">Admin</h1>

        <div className="toolbar">
          <button className="btn btn--primary" onClick={onExport}>
            Export JSON
          </button>

          <label style={{ cursor: "pointer" }}>
            <span className="btn btn--outline">Import JSON</span>
            <input
              type="file"
              accept="application/json"
              style={{ display: "none" }}
              onChange={(e) => onImport(e.target.files?.[0] ?? null)}
            />
          </label>
        </div>

        <div className="section">
          <div className="panel panel--glass">
            <div className="panel__inner">
              <ul style={{ margin: 0, paddingLeft: 18, lineHeight: 1.9 }}>
                <li>
                  <Link to="/admin/profile">개인정보 입력</Link>
                </li>
                <li>
                  <Link to="/admin/projects">프로젝트 이력 입력</Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}