import { useEffect, useMemo, useState } from "react";
import { profileStorage } from "@/services/storage/profileStorage";
import { projectStorage } from "@/services/storage/projectStorage";
import { calcTotalCareer } from "@/utils/calcCareer";
import { exportPortfolioExcel } from "@/utils/exportExcel";
import Badge from "@/components/common/Badge/Badge";
import Button from "@/components/common/Button/Button";

type Theme = "light" | "dark";
const THEME_KEY = "theme";

const Home = () => {
  const projects = projectStorage.get();
  const [theme, setTheme] = useState<Theme>("light");

  useEffect(() => {
    const savedTheme = localStorage.getItem(THEME_KEY) as Theme | null;

    if (savedTheme === "light" || savedTheme === "dark") {
      setTheme(savedTheme);
      document.documentElement.setAttribute("data-theme", savedTheme);
    } else {
      document.documentElement.setAttribute("data-theme", "light");
    }
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  const toggleTheme = () => setTheme((prev) => (prev === "light" ? "dark" : "light"));

  const profile = profileStorage.get();
  const total = useMemo(() => {
    if (!profile) return null;
    return calcTotalCareer(profile.careers);
  }, [profile]);

  if (!profile) {
    return (
      <div className="page">
        <div className="page__crumb">Home</div>
        <h1 className="page__title">포트폴리오 Home</h1>
        <p>아직 프로필 데이터가 없어요. /admin/profile에서 입력해주세요!</p>
      </div>
    );
  }

  return (
    <div className="container home">
      <div className="page">
        <div className="page__crumb">🏠 Home</div>
        <h1 className="page__title">Home</h1>

        <div className="toolbar">
          <div>
            현재 테마: <b>{theme}</b>
          </div>

          <Button size="md" variant="outline" onClick={toggleTheme}>
            테마 변경
          </Button>

          <Button
            size="md"
            variant="primary"
            onClick={() => {
              const profile = profileStorage.get();
              const projects = projectStorage.get();
              if (!profile) return alert("프로필 데이터가 없음!");
              exportPortfolioExcel(profile, projects);
            }}
          >
            Excel 다운로드
          </Button>
        </div>

        <div className="section">
          <div className="panel panel--glass">
            <div className="panel__inner">
              <div className="btn-group">
                <button className="btn btn--primary">Primary</button>
                <button className="btn btn--danger">Danger</button>
              </div>
            </div>
          </div>
        </div>

        <div className="section">
          <h2 className="section__title">{profile.name}</h2>
          <p>활동지: {profile.location}</p>

          {total && (
            <p>
              총 경력: <b>{total.years}년 {total.months}개월</b>
            </p>
          )}
        </div>

        <div className="section">
          <h2 className="section__title">Projects</h2>

          {projects.length === 0 ? (
            <p>프로젝트 데이터가 없어요. /admin/projects 에서 입력해주세요!</p>
          ) : (
            <div className="grid">
              {projects.map((p) => (
                <div key={p.id} className="card">
                  <h3 className="card__title">{p.name}</h3>
                  <p className="card__meta">{p.client} · {p.role}</p>
                  <p className="card__period">{p.startDate} ~ {p.endDate}</p>

                  <div className="btn-group" style={{ marginTop: 12 }}>
                    {p.skills.map((s) => (
                      <Badge key={s} label={s} />
                    ))}
                  </div>

                  {p.note && <p style={{ marginTop: 12 }}>{p.note}</p>}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Home;