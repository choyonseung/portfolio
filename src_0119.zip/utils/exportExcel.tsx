import type { Profile } from "@/types/profile";
import type { Project } from "@/types/project";
import * as XLSX from "xlsx";

export function exportPortfolioExcel(profile: Profile, projects: Project[]) {
  const wb = XLSX.utils.book_new();

  // 1) Profile
  const profileSheet = XLSX.utils.json_to_sheet([
    { key: "name", value: profile.name },
    { key: "location", value: profile.location },
  ]);
  XLSX.utils.book_append_sheet(wb, profileSheet, "Profile");

  // 2) Careers
  const careersSheet = XLSX.utils.json_to_sheet(
    profile.careers.map((c) => ({
      companyName: c.companyName,
      startDate: c.startDate,
      endDate: c.isCurrent ? "재직중" : c.endDate,
      isCurrent: c.isCurrent ? "Y" : "N",
    }))
  );
  XLSX.utils.book_append_sheet(wb, careersSheet, "Careers");

  // 3) Projects
  const projectsSheet = XLSX.utils.json_to_sheet(
    projects.map((p) => ({
      name: p.name,
      client: p.client,
      role: p.role,
      startDate: p.startDate,
      endDate: p.endDate,
      skills: p.skills.join(", "),
      note: p.note ?? "",
    }))
  );
  XLSX.utils.book_append_sheet(wb, projectsSheet, "Projects");

  XLSX.writeFile(wb, "portfolio.xlsx");
}