export type Project = {
  id: string;
  name: string;         // 프로젝트명
  client: string;       // 발주처
  role: string;         // 담당역할
  startDate: string;    // YYYY-MM-DD
  endDate: string;      // YYYY-MM-DD
  skillsText: string;   // 입력용 문자열)
  skills: string[];     // 사용스킬
  note?: string;        // 비고
};