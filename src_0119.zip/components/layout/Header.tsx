import { NavLink } from "react-router-dom";
import Button from "@/components/common/Button/Button";

type Theme = "light" | "dark";

type Props = {
  theme: Theme;
  onToggleTheme: () => void;
};

export default function Header({ theme, onToggleTheme }: Props) {
  return (
    <header className="header">
      <div className="header__left">
        <div className="header__brand">Portfolio</div>

        <nav className="header__nav">
          <NavLink
            to="/"
            className={({ isActive }) => `header__link ${isActive ? "is-active" : ""}`}
          >
            Home
          </NavLink>

          <NavLink
            to="/admin"
            className={({ isActive }) => `header__link ${isActive ? "is-active" : ""}`}
          >
            Admin
          </NavLink>

          <NavLink
            to="/styleguide"
            className={({ isActive }) => `header__link ${isActive ? "is-active" : ""}`}
          >
            Style Guide
          </NavLink>
        </nav>
      </div>

      <div className="header__right">
        <span style={{ fontSize: 12, opacity: 0.7 }}>Theme: {theme}</span>
        <Button size="sm" variant="outline" onClick={onToggleTheme}>
          Toggle
        </Button>
      </div>
    </header>
  );
}