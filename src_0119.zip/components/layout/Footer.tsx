export default function Footer() {
  return (
    <footer style={{ padding: "22px 0", textAlign: "center", opacity: 0.6 }}>
      © {new Date().getFullYear()} Portfolio. Built with React.
    </footer>
  );
}