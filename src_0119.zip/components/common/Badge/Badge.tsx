import styles from "./Badge.module.scss";

type Props = {
  label: string;
};

export default function Badge({ label }: Props) {
  return <span className={styles.badge}>{label}</span>;
}
