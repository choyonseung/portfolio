import React from "react";

export type ButtonSize = "xs" | "sm" | "md" | "lg" | "xl";
export type ButtonVariant = "primary" | "outline" | "ghost" | "danger";

type Props = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  size?: ButtonSize;
  variant?: ButtonVariant;
  fullWidth?: boolean;
};

export default function Button({
  size = "md",
  variant = "primary",
  fullWidth = false,
  className = "",
  ...props
}: Props) {
  const classes = [
    "btn",
    `btn--${size}`,
    `btn--${variant}`,
    fullWidth ? "btn--full" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return <button className={classes} {...props} />;
}