import { useEffect, useMemo, useState } from "react";
import type { Career, Profile } from "@/types/profile";
import { profileStorage } from "@/services/storage/profileStorage";
import { calcTotalCareer } from "@/utils/calcCareer";

import Typography from "@/components/common/Typography/Typography";
import Button from "@/components/common/Button/Button";

function createCareer(): Career {
  return {
    id: crypto.randomUUID(),
    companyName: "",
    startDate: "",
    endDate: "",
    isCurrent: false,
  };
}

export default function AdminProfile() {
  const [profile, setProfile] = useState<Profile>({
    name: "",
    location: "",
    careers: [createCareer()],
  });

  useEffect(() => {
    const saved = profileStorage.get();
    if (saved) setProfile(saved);
  }, []);

  const total = useMemo(() => calcTotalCareer(profile.careers), [profile.careers]);

  const onSave = () => {
    profileStorage.set(profile);
    alert("저장 완료!");
  };

  const onAddCareer = () => {
    setProfile((prev) => ({
      ...prev,
      careers: [...prev.careers, createCareer()],
    }));
  };

  const onRemoveCareer = (id: string) => {
    setProfile((prev) => ({
      ...prev,
      careers: prev.careers.filter((c) => c.id !== id),
    }));
  };

  const updateCareer = (id: string, patch: Partial<Career>) => {
    setProfile((prev) => ({
      ...prev,
      careers: prev.careers.map((c) => (c.id === id ? { ...c, ...patch } : c)),
    }));
  };

  return (
    <div className="page admin">
      <Typography label="Profile" level="head" size="h1">
        <Button size="md" color="primary" variant="solid" onClick={onSave}>
          저장
        </Button>

        <Button
          size="md"
          color="danger"
          variant="outline"
          onClick={() => {
            profileStorage.clear();
            alert("저장값 삭제 완료");
          }}
        >
          저장값 삭제
        </Button>
      </Typography>

      <div className="section">
        <div className="card">
          <h2 className="section__title">기본 정보</h2>

          <div className="styleguide__form">
            <label className="field">
              <span className="field__label">이름</span>
              <input
                className="input"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              />
            </label>

            <label className="field">
              <span className="field__label">거주지(활동지)</span>
              <input
                className="input"
                value={profile.location}
                onChange={(e) => setProfile({ ...profile, location: e.target.value })}
              />
            </label>
          </div>
        </div>
      </div>

      <div className="section">
        <div className="card">
          <div className="toolbar" style={{ justifyContent: "space-between" }}>
            <div>
              <h2 className="section__title" style={{ margin: 0 }}>
                회사 이력
              </h2>
              <p style={{ margin: "6px 0 0" }}>
                총 경력:{" "}
                <b>
                  {total.years}년 {total.months}개월
                </b>
              </p>
            </div>

            <Button size="md" color="primary" variant="outline" onClick={onAddCareer}>
              + 회사 추가
            </Button>
          </div>

          <div className="grid" style={{ marginTop: 14 }}>
            {profile.careers.map((c, idx) => (
              <div key={c.id} className="card">
                <div className="toolbar" style={{ justifyContent: "space-between" }}>
                  <b>#{idx + 1}</b>

                  <Button
                    size="sm"
                    color="danger"
                    variant="ghost"
                    onClick={() => onRemoveCareer(c.id)}
                  >
                    삭제
                  </Button>
                </div>

                <div className="styleguide__form" style={{ marginTop: 12 }}>
                  <label className="field">
                    <span className="field__label">회사명</span>
                    <input
                      className="input"
                      value={c.companyName}
                      onChange={(e) => updateCareer(c.id, { companyName: e.target.value })}
                    />
                  </label>

                  <div className="grid-2">
                    <label className="field">
                      <span className="field__label">시작일</span>
                      <input
                        className="input"
                        type="date"
                        value={c.startDate}
                        onChange={(e) => updateCareer(c.id, { startDate: e.target.value })}
                      />
                    </label>

                    <label className="field">
                      <span className="field__label">종료일</span>
                      <input
                        className="input"
                        type="date"
                        value={c.endDate || ""}
                        disabled={c.isCurrent}
                        onChange={(e) => updateCareer(c.id, { endDate: e.target.value })}
                      />
                    </label>
                  </div>

                  <label className="field">
                    <span className="field__label">재직중</span>
                    <input
                      type="checkbox"
                      checked={c.isCurrent}
                      onChange={(e) =>
                        updateCareer(c.id, {
                          isCurrent: e.target.checked,
                          endDate: e.target.checked ? "" : c.endDate,
                        })
                      }
                    />
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}