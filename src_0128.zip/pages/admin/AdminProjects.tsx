import { useEffect, useMemo, useState } from "react";
import type { Project } from "@/types/project";
import { projectStorage } from "@/services/storage/projectStorage";
import { getSkillBadgeStyle } from "@/utils/getSkillBadgeStyle";
import { sortSkillsByPriority } from "@/utils/sortSkills";

import Typography from "@/components/common/Typography/Typography";
import Button from "@/components/common/Button/Button";
import Badge from "@/components/common/Badge/Badge";

function createProject(): Project {
  return {
    id: crypto.randomUUID(),
    category: "Finance",
    name: "",
    client: "",
    role: "",
    startDate: "",
    endDate: "",
    skillsText: "",
    skills: [],
    note: "",
  };
}

function toSkills(text: string) {
  return text
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export default function AdminProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  useEffect(() => {
    const saved = projectStorage.get();
    setProjects(saved);
    setSelectedId(saved[0]?.id ?? null);
  }, []);

  const selected = useMemo(() => {
    return projects.find((p) => p.id === selectedId) ?? null;
  }, [projects, selectedId]);

  const onAdd = () => {
    const p = createProject();
    setProjects((prev) => [p, ...prev]);
    setSelectedId(p.id);
  };

  const onRemove = (id: string) => {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    setSelectedId((prev) => {
      if (prev !== id) return prev;
      // 삭제한 게 선택된 거면, 남은 첫번째로 자동 선택
      const remain = projects.filter((p) => p.id !== id);
      return remain[0]?.id ?? null;
    });
  };

  const update = (id: string, patch: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...patch } : p))
    );
  };

  const onSave = () => {
    const normalized = projects.map((p) => ({
      ...p,
      skills: toSkills(p.skillsText),
    }));

    setProjects(normalized);
    projectStorage.set(normalized);
    alert("저장 완료!");
  };

  return (
    <div className="page admin">
      <Typography label="Projects" level="head" size="h1">
         <Button size="md" color="primary" variant="outline" onClick={onAdd}>
          + 프로젝트 추가
        </Button>

        <Button size="md" color="primary" variant="solid" onClick={onSave}>
          저장
        </Button>

        <Button
          size="md"
          color="danger"
          variant="outline"
          onClick={() => {
            projectStorage.clear();
            alert("저장값 삭제 완료");
          }}
        >
          저장값 삭제
        </Button>
      </Typography>

      <div className="admin-projects">
        {/* LEFT: editor list */}
        <div className="admin-projects__left">
          <div className="admin-projects__list">
            {projects.map((p, idx) => {
              const isActive = p.id === selectedId;

              return (
                <div
                  key={p.id}
                  className={`card ${isActive ? "is-active" : ""}`}
                  style={{
                    borderColor: isActive ? "rgba(90,78,255,0.35)" : undefined,
                    background: isActive ? "rgba(90,78,255,0.08)" : undefined,
                  }}
                  onClick={() => setSelectedId(p.id)}
                  role="button"
                  tabIndex={0}
                >
                  <div className="toolbar" style={{ justifyContent: "space-between" }}>
                    <b>#{idx + 1}</b>

                    <Button
                      size="sm"
                      color="danger"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemove(p.id);
                      }}
                    >
                      삭제
                    </Button>
                  </div>

                  <div className="styleguide__form" style={{ marginTop: 14 }}>
                    <label className="field">
                      <span className="field__label">프로젝트명</span>
                      <input
                        className="input"
                        value={p.name}
                        onChange={(e) => update(p.id, { name: e.target.value })}
                        placeholder="AAA"
                      />
                    </label>

                    <label className="field">
                      <span className="field__label">카테고리</span>

                      <select
                        className="select"
                        value={p.category}
                        onChange={(e) => update(p.id, { category: e.target.value as Project["category"] })}
                      >
                        <option value="" disabled>카테고리 선택</option>
                        <option value="Finance">Finance</option>
                        <option value="Insurance">Insurance</option>
                        <option value="Brand">Brand</option>
                        <option value="Recruit">Recruit</option>
                        <option value="Etc">Etc</option>
                      </select>
                    </label>

                    <div className="grid-2">
                      <label className="field">
                        <span className="field__label">발주처</span>
                        <input
                          className="input"
                          value={p.client}
                          onChange={(e) => update(p.id, { client: e.target.value })}
                        />
                      </label>

                      <label className="field">
                        <span className="field__label">담당역할</span>
                        <input
                          className="input"
                          value={p.role}
                          onChange={(e) => update(p.id, { role: e.target.value })}
                        />
                      </label>
                    </div>

                    <div className="grid-2">
                      <label className="field">
                        <span className="field__label">시작일</span>
                        <input
                          className="input"
                          type="date"
                          value={p.startDate}
                          onChange={(e) => update(p.id, { startDate: e.target.value })}
                        />
                      </label>

                      <label className="field">
                        <span className="field__label">종료일</span>
                        <input
                          className="input"
                          type="date"
                          value={p.endDate}
                          onChange={(e) => update(p.id, { endDate: e.target.value })}
                        />
                      </label>
                    </div>

                    <label className="field">
                      <span className="field__label">사용스킬 (쉼표로 구분)</span>
                      <input
                        className="input"
                        value={p.skillsText}
                        onChange={(e) => update(p.id, { skillsText: e.target.value })}
                        placeholder="React, TypeScript, SCSS..."
                      />
                    </label>

                    <label className="field">
                      <span className="field__label">링크</span>
                      <input
                        className="input"
                        placeholder="https://..."
                        value={p.link ?? ""}
                        onChange={(e) => update(p.id, { link: e.target.value })}
                      />
                    </label>

                    <label className="field">
                      <span className="field__label">비고</span>
                      <textarea
                        className="textarea"
                        value={p.note || ""}
                        onChange={(e) => update(p.id, { note: e.target.value })}
                        rows={3}
                        placeholder="간단 설명..."
                      />
                    </label>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT: live preview */}
        <div className="admin-projects__right">
          <div className="panel panel--glass">
            <div className="panel__inner">
              <div className="admin-projects__previewTitle">
                <h2 className="section__title" style={{ margin: 0 }}>
                  Live Preview
                </h2>
              </div>

              {!selected ? (
                <p style={{ margin: 0, color: "var(--color-text-muted)" }}>
                  선택된 프로젝트가 없어요.
                </p>
              ) : (
                <ProjectPreviewCard project={selected} />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/** Home 카드와 최대한 동일한 형태로 미리보기 */
function ProjectPreviewCard({ project }: { project: Project }) {
  const skills = toSkills(project.skillsText);

  return (
    <div className="card" style={{ marginTop: 10 }}>
      <div>
        <h3 className="card__title">{project.name || "프로젝트명"}</h3>
        {project.category && <p className="card__sub">{project.category}</p>}
      </div>

      <p className="card__meta">
        {(project.client || "Client") + " · " + (project.role || "Role")}
      </p>

      <p className="card__period">
        {(project.startDate || "YYYY-MM-DD") + " ~ " + (project.endDate || "YYYY-MM-DD")}
      </p>

      <div className="btn-group" style={{ marginTop: 12 }}>
        {skills.length ? sortSkillsByPriority(skills).map((s) => {
          const ui = getSkillBadgeStyle(s);
          return (
            <Badge
              key={s}
              label={ui.label}
              color={ui.color}
              variant={ui.variant}
            />
          );
        }) : null}
      </div>

      {project.link ? (
        <a
          className="card__link"
          href={project.link}
          target="_blank"
          rel="noreferrer"
        >
          View
        </a>
      ) : null}

      {project.note ? <p style={{ marginTop: 12 }}>{project.note}</p> : null}
    </div>
  );
}