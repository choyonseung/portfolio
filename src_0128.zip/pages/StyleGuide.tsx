import { Plus, X } from "lucide-react";
import Typography from "@/components/common/Typography/Typography";
import Button from "@/components/common/Button/Button";
import Badge from "@/components/common/Badge/Badge";
import Field from "@/components/common/Form/Field";
import Input from "@/components/common/Form/Input";
import Textarea from "@/components/common/Form/Textarea";
import Select from "@/components/common/Form/Select";

export default function StyleGuide() {
  const categoryOptions = [
    { label: "Finance", value: "finance" },
    { label: "Insurance", value: "insurance" },
    { label: "Brand", value: "brand" },
    { label: "Recruit", value: "recruit" },
    { label: "Etc", value: "etc" },
  ];


  return (
    <div className="page styleguide">
      <Typography label="Style Guide" level="head" size="h1" />

      <p className="styleguide__desc">
        Tokens 기반으로 구성된 컴포넌트/테마 시스템 미리보기 화면입니다.
      </p>

      {/* Foundations */}
      <section className="styleguide__section">
        <Typography label="Foundations" level="head" size="h2" />

        <div className="grid-2">
          <div className="panel panel--glass">
            <div className="panel__inner">
              <h3 className="styleguide__subtitle">Colors</h3>

              {/* Palette */}
              <div className="styleguide__colorBlock">
                <div className="styleguide__blockTitle">Palette</div>
                <div className="styleguide__swatches">
                  <div className="swatch swatch--bg">bg</div>
                  <div className="swatch swatch--surface">surface</div>
                  <div className="swatch swatch--primary">primary</div>
                  <div className="swatch swatch--accent">accent</div>
                  <div className="swatch swatch--pink">pink</div>
                </div>
              </div>

              {/* Semantic */}
              <div className="styleguide__colorBlock">
                <div className="styleguide__blockTitle">Semantic</div>
                <div className="styleguide__swatches styleguide__swatches--semantic">
                  <div className="swatch swatch--info">info</div>
                  <div className="swatch swatch--success">success</div>
                  <div className="swatch swatch--warning">warning</div>
                  <div className="swatch swatch--danger">danger</div>
                </div>
              </div>

            </div>
          </div>

          <div className="panel panel--glass">
            <div className="panel__inner">
              <h3 className="styleguide__subtitle">Typography</h3>

              <div className="styleguide__typo">
                <Typography label="Head H1" level="head" size="h1" />
                <Typography label="Head H2" level="head" size="h2" />
                <Typography label="Head H3" level="head" size="h3" />
                <Typography label="Head H4" level="head" size="h4" />
                <Typography label="Head H5" level="head" size="h5" />
                <Typography label="Body H1" level="body" size="h1" />
                <Typography label="Body H2" level="body" size="h2" />
                <Typography label="Body H3" level="body" size="h3" />
                <Typography label="Body H4" level="body" size="h4" />
                <Typography label="Body H5" level="body" size="h5" />
                <Typography label="Info H1" level="info" size="h1" />
                <Typography label="Info H2" level="info" size="h2" />
                <Typography label="Info H3" level="info" size="h3" />
                <Typography label="Info H4" level="info" size="h4" />
                <Typography label="Info H5" level="info" size="h5" />
                <Typography label="Head H3" level="head" size="h3">
                  <Button size="md" color="primary" variant="solid">Button</Button>
                </Typography>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Components */}
      <section className="styleguide__section">
        <Typography label="Components" level="head" size="h2" />

        <div className="grid-2">
          <div className="card">
            <h3 className="styleguide__subtitle">Buttons</h3>

            <div className="styleguide__row">
              <Button size="xs" color="primary" variant="solid">XS</Button>
              <Button size="sm" color="primary" variant="solid">SM</Button>
              <Button size="md" color="primary" variant="solid">MD</Button>
              <Button size="lg" color="primary" variant="solid">LG</Button>
              <Button size="xl" color="primary" variant="solid">XL</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" color="primary" variant="solid">Primary</Button>
              <Button size="md" color="neutral" variant="solid">neutral</Button>
              <Button size="md" color="accent" variant="solid">accent</Button>
              <Button size="md" color="pink" variant="solid">pink</Button>
              <Button size="md" color="info" variant="solid">info</Button>
              <Button size="md" color="success" variant="solid">success</Button>
              <Button size="md" color="warning" variant="solid">warning</Button>
              <Button size="md" color="danger" variant="solid">danger</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" color="primary" variant="solid" disabled>Primary</Button>
              <Button size="md" color="neutral" variant="solid" disabled>neutral</Button>
              <Button size="md" color="accent" variant="solid" disabled>accent</Button>
              <Button size="md" color="pink" variant="solid" disabled>pink</Button>
              <Button size="md" color="info" variant="solid" disabled>info</Button>
              <Button size="md" color="success" variant="solid" disabled>success</Button>
              <Button size="md" color="warning" variant="solid" disabled>warning</Button>
              <Button size="md" color="danger" variant="solid" disabled>danger</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" color="primary" variant="outline">Primary</Button>
              <Button size="md" color="neutral" variant="outline">neutral</Button>
              <Button size="md" color="accent" variant="outline">accent</Button>
              <Button size="md" color="pink" variant="outline">pink</Button>
              <Button size="md" color="info" variant="outline">info</Button>
              <Button size="md" color="success" variant="outline">success</Button>
              <Button size="md" color="warning" variant="outline">warning</Button>
              <Button size="md" color="danger" variant="outline">danger</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" color="primary" variant="outline" disabled>Primary</Button>
              <Button size="md" color="neutral" variant="outline" disabled>neutral</Button>
              <Button size="md" color="accent" variant="outline" disabled>accent</Button>
              <Button size="md" color="pink" variant="outline" disabled>pink</Button>
              <Button size="md" color="info" variant="outline" disabled>info</Button>
              <Button size="md" color="success" variant="outline" disabled>success</Button>
              <Button size="md" color="warning" variant="outline" disabled>warning</Button>
              <Button size="md" color="danger" variant="outline" disabled>danger</Button>
            </div>

            <div className="styleguide__row">
              <Button size="md" color="primary" variant="solid" iconLeft={<Plus />}>추가</Button>
              <Button size="md" color="primary" variant="outline" iconRight={<X />}>닫기</Button>
              <Button size="md" color="neutral" variant="ghost" iconLeft={<X />} ariaLabel="삭제"></Button>
            </div>

            <div className="styleguide__row">
              <div className="btn-group">
                <Button size="md" color="primary" variant="outline" fullWidth>Button</Button>
                <Button size="md" color="primary" variant="solid" fullWidth>Button</Button>
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Inputs</h3>

            <div className="styleguide__form">

              <Field label="프로젝트명" required>
                <Input type="text" placeholder="프로젝트명" />
              </Field>

              <Field label="카테고리">
                <Select
                  placeholder="카테고리 선택"
                  options={categoryOptions}
                />
              </Field>

              <Field label="시작일">
                <Input type="date" placeholder="YYYY-MM-DD" />
              </Field>

              <Field label="비고">
                <Textarea placeholder="간단 설명..." rows={4} />
              </Field>
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Badges</h3>
            <div className="styleguide__row">
              <div className="badge-group">
                <Badge color="primary" variant="solid" label="React" />
                <Badge color="accent" variant="solid" label="TypeScript" />
                <Badge color="pink" variant="solid" label="SCSS" />
                <Badge color="info" variant="solid" label="Vite" />
                <Badge color="success" variant="solid" label="Vite" />
                <Badge color="warning" variant="solid" label="Vite" />
              </div>
            </div>
            <div className="styleguide__row">
              <div className="badge-group">
                <Badge color="primary" variant="outline" label="React" />
                <Badge color="accent" variant="outline" label="TypeScript" />
                <Badge color="pink" variant="outline" label="SCSS" />
                <Badge color="info" variant="outline" label="Vite" />
                <Badge color="success" variant="outline" label="Vite" />
                <Badge color="warning" variant="outline" label="Vite" />
              </div>
            </div>
          </div>

          <div className="card">
            <h3 className="styleguide__subtitle">Cards</h3>
            <div className="card">
              <h4 className="card__title">Project Card</h4>
              <p className="card__meta">Client · Role</p>
              <p className="card__period">2025-01-01 ~ 2025-12-31</p>
              <div className="badge-group">
                <Badge variant="solid" color="primary" label="React" />
                <Badge variant="solid" color="warning" label="JavaScript" />
              </div>
              <p className="card__link">View Link</p>
              <p className="card__note">Note</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
