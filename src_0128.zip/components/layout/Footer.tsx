export default function Footer() {
  return (
    <footer className="footer">
      © {new Date().getFullYear()} Portfolio. Built with React.
    </footer>
  );
}