import React, { forwardRef } from "react";
import type { SelectHTMLAttributes } from "react";

export interface SelectOption {
  label: string;
  value: string | number;
  disabled?: boolean;
}

interface SelectProps
  extends SelectHTMLAttributes<HTMLSelectElement> {
  error?: boolean;
  options?: SelectOption[];
  placeholder?: string;
}

const Select = forwardRef<HTMLSelectElement, SelectProps>(
  (
    {
      error,
      className = "",
      options,
      placeholder,
      children,
      ...props
    },
    ref
  ) => {
    const classes = `select ${error ? "-error" : ""} ${className}`;

    return (
      <select ref={ref} className={classes.trim()} {...props}>
        {placeholder && (
          <option value="" disabled hidden>
            {placeholder}
          </option>
        )}

        {options &&
          options.map((opt) => (
            <option
              key={opt.value}
              value={opt.value}
              disabled={opt.disabled}
            >
              {opt.label}
            </option>
          ))}

        {children}
      </select>
    );
  }
);

export default Select;
