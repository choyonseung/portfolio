interface FieldProps {
  label?: string;
  required?: boolean;
  children: React.ReactNode;
}

export default function Field({ label, required, children }: FieldProps) {
  return (
    <label className="field">
      {label && (
        <span className="field-label">
          {label}
          {required && <em className="field-required">*</em>}
        </span>
      )}
      {children}
    </label>
  );
}
