import React, { forwardRef, useState } from "react";
import type { InputHTMLAttributes } from "react";

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ type = "text", error, className = "", ...props }, ref) => {
    const [showPassword, setShowPassword] = useState(false);

    const isPassword = type === "password";
    const inputType = isPassword && showPassword ? "text" : type;

    const classes = `input ${error ? "-error" : ""} ${
      isPassword ? "has-toggle" : ""
    } ${className}`;

    return (
      <div className="input-wrap">
        <input ref={ref} type={inputType} className={classes.trim()} {...props} />

        {/* password 토글 버튼 */}
        {isPassword && (
          <button
            type="button"
            className="input-toggle"
            onClick={() => setShowPassword((prev) => !prev)}
          >
            {showPassword ? "🙈" : "👁"}
          </button>
        )}
      </div>
    );
  }
);

export default Input;
