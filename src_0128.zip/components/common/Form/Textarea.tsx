import React, { forwardRef } from "react";
import type { TextareaHTMLAttributes } from "react";

interface TextareaProps
  extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  error?: boolean;
}

const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ error, className = "", ...props }, ref) => {
    const classes = `textarea ${error ? "-error" : ""} ${className}`;

    return <textarea ref={ref} className={classes.trim()} {...props} />;
  }
);

export default Textarea;