import { Info } from "lucide-react";
import type { ReactNode } from "react";

export type TypographyLevel = "head" | "body" | "info";
export type TypographySize = "h1" | "h2" | "h3" | "h4" | "h5";

type Props = {
  label: string;
  labelHidden?: boolean;
  level?: TypographyLevel;
  size?: TypographySize;
  color?: string;
  className?: string;
  children?: ReactNode;
};

export default function Typography({
  label,
  labelHidden,
  level = "body",
  size = "h4",
  color,
  children,
}: Props) {

  const Tag = level === 'head' ? size : 'p';

  return (
    <div className="typography">
      <div className={`typography-${level}`}>
        {level === "info" && (
          <span className="mark">
            <Info color={color} />
          </span>
        )}
        <Tag className={`${size} ${labelHidden ? "blind" : ""}`}
          >
          {label}
        </Tag>
      </div>
      {children && (
        <div className="typography-sub">
          {children}
        </div>
      )}
    </div>
  );
}
