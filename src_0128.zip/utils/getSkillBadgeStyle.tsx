import type { BadgeColor, BadgeVariant } from "@/components/common/Badge/Badge";

type SkillBadgeUI = {
  label: string;
  color: BadgeColor;
  variant: BadgeVariant;
};

export function getSkillBadgeStyle(skill: string): SkillBadgeUI {
  const raw = skill.trim();
  const s = raw.toLowerCase();

  /* Skill Color Policy */
  const colorMap: Record<string, BadgeColor> = {
    "responsive web" : "success",
    "web" : "success",
    "mobile" : "success",
    "tablet" : "success",
    "docker" : "success",
    "aws" : "success",

    "html" : "primary",
    "react" : "primary",
    "next.js" : "primary",
    "react native" : "primary",

    "scss" : "pink",
    "sass" : "pink",
    "css" : "pink",
    "styled-components" : "pink",
    "emotion" : "pink",
    "tailwind css" : "pink",

    "typescript" : "warning",
    "javascript" : "warning",
    "jquery" : "warning",

    "vite" : "info",
    "webpack" : "info",
    "eslint" : "info",
    "prettier" : "info",
    "npm" : "info",
    "yarn" : "info",
    "pnpm" : "info",
    "git" : "info",
    "github" : "info",

    "storybook" : "accent",
    "mui" : "accent",
    "figma" : "accent",
  };

  /* 표기 통일 */
  const labelMap: Record<string, string> = {
    "responsive web" : "Responsive Web",
    "web" : "Web",
    "mobile" : "Mobile",
    "tablet" : "Tablet",
    "docker" : "Docker",
    "aws" : "AWS",

    "html" : "HTML",
    "react" : "React",
    "next.js" : "React",
    "react native" : "React Native",

    "scss" : "SCSS",
    "sass" : "SASS",
    "css" : "CSS",
    "styled-components" : "Styled-components",
    "emotion" : "Emotion",
    "tailwind css" : "Tailwind",

    "typescript" : "TypeScript",
    "javascript" : "JavaScript",
    "jquery" : "jQuery",

    "vite" : "Vite",
    "webpack" : "Webpack",
    "eslint" : "ESlint",
    "prettier" : "Prettier",
    "npm" : "npm",
    "yarn" : "yarn",
    "pnpm" : "pnpm",
    "git" : "Git",
    "github" : "Github",

    "storybook" : "Storybook",
    "mui" : "MUI",
    "figma" : "Figma",
  };

  const label =
    labelMap[s] ?? (raw ? raw.charAt(0).toUpperCase() + raw.slice(1) : "");

  const color = colorMap[s] ?? "info";

  return { label, color, variant: "solid" };
}